import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
public class SimulacaoBBB extends JFrame implements ActionListener {
    private final ArrayList<Participante> participantes;
    private final JComboBox<String> participantesComboBox;
    private final JTextArea textArea;

    public SimulacaoBBB() {
        participantes = new ArrayList<>();

        participantes.add(new Participante("Chico Moedas"));
        participantes.add(new Participante("Juliete"));
        participantes.add(new Participante("Gil do Vigor"));
        participantes.add(new Participante("Maria das Dores"));

        setTitle("Simulação BBB");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());

        JLabel label = new JLabel("Votar:");
        topPanel.add(label, BorderLayout.WEST);

        String[] nomesParticipantes = new String[participantes.size()];
        for (int i = 0; i < participantes.size(); i++) {
            nomesParticipantes[i] = participantes.get(i).getNome();
        }
        participantesComboBox = new JComboBox<>(nomesParticipantes);
        topPanel.add(participantesComboBox, BorderLayout.CENTER);

        JButton button = new JButton("Votar");
        button.addActionListener(this);
        topPanel.add(button, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    public static void main(String[] args) {
        new SimulacaoBBB();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String nomeSelecionado = (String) participantesComboBox.getSelectedItem();
        if (nomeSelecionado != null) {
            Participante participante = getParticipantePorNome(nomeSelecionado);
            if (participante != null) {
                participante.votar();
                atualizarResultados();
            }
        }
    }

    private Participante getParticipantePorNome(String nome) {
        for (Participante participante : participantes) {
            if (participante.getNome().equals(nome)) {
                return participante;
            }
        }
        return null;
    }

    private void atualizarResultados() {
        StringBuilder sb = new StringBuilder();
        sb.append("Resultado da votação:\n");
        for (Participante participante : participantes) {
            sb.append(participante).append("\n");
        }

        Participante eliminado = Collections.max(participantes, (p1, p2) -> Integer.compare(p1.getVotos(), p2.getVotos()));
        sb.append("\n").append(eliminado.getNome()).append(" foi eliminado!\n");
        participantes.remove(eliminado);
        participantesComboBox.removeItem(eliminado.getNome());

        sb.append("\nParticipantes restantes:\n");
        for (Participante participante : participantes) {
            sb.append(participante.getNome()).append("\n");
        }

        textArea.setText(sb.toString());
    }
}

//Lucas Carvalho de Oliveira - 12121511