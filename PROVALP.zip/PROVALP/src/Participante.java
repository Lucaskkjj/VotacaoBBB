import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

class Participante {
    private String nome;
    private int votos;

    public Participante(String nome) {
        this.nome = nome;
        this.votos = 0;
    }

    public String getNome() {
        return nome;
    }

    public int getVotos() {
        return votos;
    }

    public void votar() {
        this.votos++;
    }

    @Override
    public String toString() {
        return nome + ": " + votos + " votos";
    }
}

//Lucas Carvalho de Oliveira - 12121511